# udacity-bikeshare-project
Using python to analyze bikeshare ridership data from three US cities. An assigned project from Udacity Data Analysis Nanodegree term 1.

Throughout this project I did a lot of googling and used various little pieces of
code from places like stackexchange, the python documentation, and quora.
